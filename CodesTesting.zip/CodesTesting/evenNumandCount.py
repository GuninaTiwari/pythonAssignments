m = int(input("Enter no. 1 : "))
n = int(input("Enter no. 2 : "))
while m<=n :
    if m%2==0 :
        print(m,end=",")
    m+=1

if m%2!=0:
    m+=1

while m<=n :
    print(m,end=",")
    m+=2

for i in range(m,n+1,1) :
    if i%2==0 :
        print(i,end=",")

for i in range(m,n+1,1) :
    if i%2==0 :
        print(i,end=",")

for i in range(m,n+1,2) :
    print(i,end=",")


