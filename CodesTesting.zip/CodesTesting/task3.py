a = int(input("Enter no. 1 : "))
b = int(input("Enter no. 2 : "))
c = int(input("Enter no. 3 : "))
if (a==7 and b!=7 and c!=7):
	ans = b*c
	print(ans)
elif(b==7 and a!=7 and c!=7) :
	ans = c
	print(ans)
elif(c==7 ) :
	ans = -1
	print(ans)
else :
	print(a*b*c)

