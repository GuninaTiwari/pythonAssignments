'''
list list used to create a collection of different types of values

theres no limit to create a list & it is resizable

list in python is a function & it creates array collection in sequential form

syntax : 
    users = list()
    or
    users =[]

functions 
---------
1) append()
2) extend()

'''

from turtle import color


numbers = list()
numbers.append(38)
numbers.append(40)
numbers.append(48)
print(numbers)

colors = []
colors.append("red")
colors.append("Orange")
print(colors)

users =["Smith","Johns","Eliz","Kang"]
for i in range(0,len(users)):
    print(users[i])
    