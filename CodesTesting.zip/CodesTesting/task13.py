def print_pattern(n):
    for n in range(n, 0, -1):
        print('*' * n)
rows = 5
print_pattern(rows)
 