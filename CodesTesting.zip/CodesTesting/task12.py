def can_form_triangle(a, b, c):
    # Check if any side is greater than or equal to the sum of the other two
    if (a >= b + c) or (b >= a + c) or (c >= a + b):
        return False
    return True

# Example usage
num1 = int(input("Enter the first side length: "))
num2 = int(input("Enter the second side length: "))
num3 = int(input("Enter the third side length: "))

if can_form_triangle(num1, num2, num3):
    print("The numbers can form the sides of a triangle.")
else:
    print("The numbers cannot form the sides of a triangle.")
