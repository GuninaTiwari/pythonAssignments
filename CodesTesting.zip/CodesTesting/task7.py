food = input("enter combo : ")
comboNum = int(input("How many combo?"))
distance = int(input("How much distance in km?"))
if food == "v" :
    print("Vegeterian food")
    if distance <=3 :
          total = comboNum*120
          print("Total cost is : ",total)

    elif 3<distance<6 :
          total = (comboNum*120)+((distance-3)*3)
          print("Total cost is : ",total )
    
    elif distance>=6 :
          total = (comboNum*120)+((distance-3)*6)
          print("Total cost is : ",total)
    

elif food == "n" :
     print("Nonveg Combo")
     if distance <=3 :
          total = comboNum*150
          print("Total cost is : ",total)

     elif 3<distance<6 :
          total = (comboNum*150)+((distance-3)*3)
          print("Total cost is : ",total )
    
     elif distance>=6 :
          total = (comboNum*150)+((distance-3)*6)
          print("Total cost is : ",total)
else :
        print("garbage value")
