inr = int(input("Enter INR needed : "))
currency = input("Enter your currency name :")
if currency!="Euro" and currency!="BritishPound" and currency!="AustralianDollar" and currency!="CanadianDollar" :
    print("-1")
else :
    if currency== "Euro":
        exchangeAmount = inr*0.01417
        print(exchangeAmount)
    elif currency== "BritishPound":
        exchangeAmount = inr*0.0100
        print(exchangeAmount)

    elif currency== "AustralianDollar":
        exchangeAmount = inr*0.02140
        print(exchangeAmount)

    elif currency== "CanadianDollar" :
        exchangeAmount = inr*0.02027
        print(exchangeAmount)





