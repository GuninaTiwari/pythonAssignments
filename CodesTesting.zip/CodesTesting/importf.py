import BankAcc as b # or : from foldername.filename import func()
accno = 0
accname = ""
opening_balance=0



while True:
    print("1. Add Account")
    print("2. Show Account")
    print("3. Deposit Money")
    print("4. Withdraw Amount")
    print("5. Statement")
    print("6. Exit")

    choice = int(input("select option :"))

    if choice==1:
        b.addAccount()
    elif choice==2:
        b.showAcc()
    elif choice==3:
        b.depositMoney()
    elif choice==4:
        b.withdrawAmount()
    
