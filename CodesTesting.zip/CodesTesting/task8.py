account_number = (input("Enter acc number : "))
account_balance = int(input("Enter acc balance : "))
salary = int(input("Enter salary : "))
loan_type = input("Enter loan type : ")
loan_amount_expected = int(input("Enter loan amt expected : "))
customer_emi_expected = int(input("Enter expected emi "))
if len(account_number) == 4 and account_number[0] ==1 and account_balance>= 100000:

    if loan_type == "car loan" :
        if salary>=25000 and customer_emi_expected>=36 : 
            print("Customer is eligible for car loan \n for amount : 500000 \n No.of EMIs to repay : 36")
        else :
            print("Ineligible to vote")
    if loan_type == "House loan" :
        if salary>=50000 and customer_emi_expected>=60 : 
            print("Customer is eligible for car loan \n for amount : 6000000 \n No.of EMIs to repay : 60")
        else :
            print("Ineligible to vote")
    if loan_type == "Business loan" :
        if salary>=75000 and customer_emi_expected>=84 : 
            print("Customer is eligible for car loan \n for amount : 7500000 \n No.of EMIs to repay : 84")
        else :
            print("Ineligible to vote")

else :
    print("Not eligible for loan")      
