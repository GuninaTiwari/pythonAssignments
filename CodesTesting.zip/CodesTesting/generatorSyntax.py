import random
#Generator syntax in list

numbers = [1,4,3,2,9,4]

#Q1 print addition of nos

total = sum(numbers)
print("Addition of list items : ",total)

min_value = min(numbers)
print("Minimum value = ", min_value)

max_value = max(numbers)
print("Maximum value : ", max_value)

#Q2 print only even nos

for item in numbers :
    if item%2==0 :
        print(item)

print("Even numbers are : ")
even_numbers = [item for item in numbers if item%2==0]
print(even_numbers)

#Q3 Replace each list item with its square

sqnum = [item**2 for item in numbers]
print(sqnum)

lst = [1,3,4]
lst = [item*item for item in lst ]
print(lst)

#Q4 create a new list with random numbers for total size 10 

#Print random 5 evn and 5 odd numbers in nested list
# sample output : [[76,42,52,86,22],[11,81,53,67,95]]

output = [[],[]]
while True :
    no = round(random()*100,0)
    if no%2==0 and len(output[0])<=4:
        output[1].append(no)
    else :
        break
print(output)


 