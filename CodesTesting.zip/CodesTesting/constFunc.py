#WAP to inherit a class and extend their properties

class Car:

    def __init__(self, carname="BMW", carmodel="x10", color="white", cost=100000):
        self.carname = carname
        self.carmodel = carmodel
        self.color = color
        self.cost = cost

    def __str__(self):
        return f"{self.carname} \t {self.carmodel} \t {self.color} \t {self.cost}"


class Sales(Car):
    sales_list = list()
    def __init__(self, carDetails=None):
        if carDetails!=None:
            super().__init__(carDetails['carname'], carDetails['model'], carDetails['color'], carDetails['cost'])
        else:
            super().__init__()
        self.sales_list.append(self)

    def purchaseCar(self, date, downpayment, customer):
        self.date = date
        self.downpayment = downpayment
        self.customer = customer

    def showSales(self):
        print("Car Details = ", super().__str__())
        print("Sales Details = ", self.date, self.downpayment, self.customer)


s1 = Sales()
s1.purchaseCar("10-Jan-2024", 80000, "smith")
s1.showSales()

s2 = Sales({'carname':"Ferrari", 'model':"F10", 'color':"red", 'cost':7000000})
s2.purchaseCar("18-Feb-2024", 600000, "peter")
s2.showSales()

s3 = Sales({'carname':"Audi", 'model':"Q10", 'color':"Black", 'cost':7000000})
s3.purchaseCar("11-Feb-2024", 600000, "Gunina")
s3.showSales()

print(f"{'Car Name':<16} {'Model':<15} {'Color':<10} {'Price'}")
print("-"*45)
for item in Sales.sales_list: 
    print(f"{item}\t")

