c = 3+4
print(c)