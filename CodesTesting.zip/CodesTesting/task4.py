x = int(input("No. of 5 rupee coins : "))
y = int(input("No. of 1 rupee coins: "))
z = int(input("Thing amount : "))
if z<<(x*5)+y and z%5==0 :
	print("5 rupee coins needed : ",z//5)
elif z<<(x*5)+y and z%5!=0 :
	print("5 rupee coins needed : ",z//5)
	print("1 rupee coins needed : ",z%5)
elif z>>((x*5)+y ):
	print("-1")
