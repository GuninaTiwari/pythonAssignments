word = input("Enter :")
rev = word[::-1]

if word==rev:
    print("Number is palindrome")
else :
    print("Number isnt palindrome")