'''
    wap to input bracket sequence & validate whether thatsequence is valid or not

    sample input : {()}[]<> is valid , {(})[]<> is invalid 
'''

def valid(sequence):
    dict = {'}':'{',']':'[',')':'(','>':'<'}
    stack = []
    for i in sequence:
        if i in dict.values():
            stack.append(i)
 
        elif stack and dict[i] == stack[-1]:
            stack.pop()
        else:
            return False
           
    return len(stack) == 0
 
sequence = input("enter the brackets sequence : ")
if valid(sequence):
    print("Sequence is valid brackets")
else:
    print("not valid")