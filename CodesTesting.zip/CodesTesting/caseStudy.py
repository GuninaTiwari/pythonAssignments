menus = [
    {'code':'M801', 'itemname':'sandwich', 'price':190, 'stock':True},
    {'code':'M802', 'itemname':'pizza', 'price':150, 'stock':False},
    {'code':'M803', 'itemname':'burger', 'price':160, 'stock':True},
    {'code':'M804', 'itemname':'colddrink', 'price':50, 'stock':True},
    {'code':'M805', 'itemname':'coffee', 'price':70, 'stock':True},
    {'code':'M806', 'itemname':'roll', 'price':150, 'stock':True}
]


ordersList = list()

while True:
    print("[1]. Show Menu List")
    print("[2]. Make Order")
    print("[3]. Show Orders List")
    print("[4]. Inventories")
    print("[5]. Exit")

    choice = int(input("Select Menu :"))

    if choice==1:
        def print_menu(menus):
            print(f"{'Code':<16} {'Item Name':<15} {'Price':<10} {'In Stock'}")
            print("-" * 45)
            for item in menus:
                print(f"{item['code']:<6} {item['itemname']:<15} {item['price']:<10} {'Yes' if item['stock'] else 'No'}")

        print_menu(menus)

    elif choice==2:
        def get_order():
            order_input = input("Enter your order (e.g., 'M801 3, M804 2'): ")
            order_items = order_input.split(',')
            return [item.strip().split() for item in order_items]

        def print_order_summary(order):
            print("\nOrder Summary:")
            total_cost = 0

            for item in order:
                code = item[0]
                qty = int(item[1])
                found_item = None
                
                for menu in menus:
                    if menu['code'] == code:
                        found_item = menu
                        break

                if found_item and found_item['stock']:
                    total = found_item['price'] * qty
                    total_cost += total
                    print(f"{code} - {found_item['itemname']}: {qty} x {found_item['price']} = {total}")
                else:
                    print(f"{code} - Unavailable")

            print(f"Total Cost: {total_cost}")

        order = get_order()
        print_order_summary(order)


    elif choice==3:
        pass
    elif choice==4:
        pass
    elif choice==5:
        break
    else:
        print("Invalid menu. try again")

