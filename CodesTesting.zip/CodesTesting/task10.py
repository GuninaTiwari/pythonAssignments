def is_leap_year(year):
    return (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0)

def next_leap_years(start_year, count=15):
    leap_years = []
    year = start_year
    
    while len(leap_years) < count:
        if is_leap_year(year):
            leap_years.append(year)
        year += 1
    return leap_years


start_year = int(input("Enter a starting year: "))
leap_years_list = next_leap_years(start_year)

print("The next 15 leap years starting from", start_year, "are:", leap_years_list)
