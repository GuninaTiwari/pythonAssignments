a = 4
b =3
c = a+b
print(c)
