'''
153 is an armstrong no. as :
1*1*1 + 5*5*5 + 3*3*3 = 153
'''
#method 1
'''no = input("Enter number : ")
sum  =0
for d in no :
    x = int(d)
    cube = x*x*x
    sum +=cube

if sum==int(no):
    print("It is armstrong num")
else :
    print("its not armstrong")'''

#method 2 - itd print armstrongs in range

for i in range(153,1001,1):
    sum =0
    no =str(i)
    for d in no:
        x = int(d)
        cube = x*x*x 
        sum+=cube
    if sum==i :
        print(i)
