//ques1
	
use("ecommerceHost");
db.createCollection("products")
db.createCollection("categories")
 

//ques2
db.categoriess.insertMany([
    {
   _id: 1,
   name: "Electronics",
   description: "Devices and gadgets"
 },
 {
   _id: 2,
   name: "Books",
   description: "Books of all genres"
 },
 {
   _id: 3,
   name: "Clothing",
   description: "Men's and women's apparel"
 }])
 db.products.insertMany([
    {
        _id: 101,
        name: "Smartphone",
        price: 499.99,
        stock: 150,
        category_ids: [1],
        details: {
          brand: "Brand A",
          features: ["5G", "OLED Display", "128GB Storage"]
        }
      },
      {
        _id: 102,
        name: "Laptop",
        price: 999.99,
        stock: 50,
        category_ids: [1],
        details: {
          brand: "Brand B",
          features: ["Intel i7", "16GB RAM", "512GB SSD"]
        }
      },
      {
        _id: 103,
        name: "Python Programming Book",
        price: 29.99,
        stock: 200,
        category_ids: [2],
        details: {
          author: "John Doe",
          pages: 400
        }
      }    
])
 
//ques3

	db.categories.find({'name':'Electronics'});

//ques4

	db.products.updateOne(

     { "_id": 101 },
    
     { "$set": { 'stock': 200 } }
    
     );

//ques5

    db.products.find(
        {
        "price": { $gt: 500 } ,
        "stock": { $gt: 0 }
        }
    );
//ques6
    use("ecommerceHost");
    db.products.updateOne(
        { name: "Smartphone",},
        { $mul: { price: 0.9 } }
    );
//ques7

    use("ecommerceHost");
    db.products.aggregate([
        { $match: { category_ids: 2 } },
        { $group: { _id: null, totalStock: { $sum: "$stock" } } }
    ])
//ques8
            use("ecommerceHost");
            db.products.insertMany([
                {
                    _id: 112,
                    name: "Fabric",
                    price: 699.99,
                    stock: 50,
                    category_ids: [3],
                    details: {
                    brand: "Brand B",
                    features: ["satin", "5 meters"]
                    }
                },
                {
                    _id: 123,
                    name: "Java Programming Book",
                    price: 29.99,
                    stock: 0,
                    category_ids: [2],
                    details: {
                    author: "John Doe",
                    pages: 400
                    }
                }
            ])

    use("ecommerceHost");
    db.products.find(
        {$or: [{"price":  { $lt: 200 }}, {category_ids: [3]}]}
    );


//ques9
    use("ecommerceHost");
    db.products.deleteMany({ stock: 0  })