//ques1
function moveZero(num1){
    let result = [];
    let count = 0;
    
    for(let i = 0; i< num1.length; i++){
        if(num1[i] === 0){
            count++;
        }
        else{
            result.push(num1[i]);
        }
    }
    
    for(let i = 0; i< count; i++){
        result.push(0);
    }
   return result
}
let nums1 = [1,0,2,0,3,0,4]
console.log(moveZero(nums1))

// //ques2
function rotateArr(num1 , steps){
    let n = num1.length;
    steps = steps % n;
    let rotate = [];
    
    for(let i = 0; i<n; i++){
        rotate[(i + steps) % n] = num1[i];
    }
    return rotate
}
let nos1 = [1,2,3,4,5]
console.log(rotateArr(nos1,6))

//ques3
function chunkArr(num1 , step){
    let result =[];
    for(let i = 0; i < num1.length; i += step){
        let chunk = [];
        for(let j = i; j< i+ step && j < num1.length; j++){
            chunk.push(num1[j]);
        }
        result.push(chunk);
    }
    return result
}

let num1 = [1,2,3,4,5,6,7]
console.log(chunkArr(num1,2))

//ques4
function flattenArray(num1){
    let result =[];
    
    function flatten(num){
        if(Array.isArray(num)){
            for(let i = 0; i < num.length; i++){
                flatten(num[i]);
            }
        }
        else{
            result.push(num);
        }
    }
    
    flatten(num1)
    return result;
}

let nu1 = [[1, 2],[3, 4, [5, 6]]]
console.log(flattenArray(nu1))

//ques5
function longestSeq(num1){
    let numSet = new Set(num1);
    let longest = 0;
    
    for(let num of numSet){
        if(!numSet.has(num-1)){
            let currentNum = num;
            let currentSeq = 1;
            
            while(numSet.has(currentNum + 1)){
                currentNum++;
                currentSeq++;
            }
            longest = Math.max(longest,currentSeq)
        }
    }
 return longest       
}

let nm1 = [1,6,2,6,5,4]
console.log(longestSeq(nm1))

//ques6
function findPairsWithSum(num1, targetSum) {
    let pairs = [];
    let seen = {};

    for (let i = 0; i < num1.length; i++) {
        let complement = targetSum - num1[i];
        if (seen[complement]) {
            pairs.push([complement, num1[i]]);
        }
        seen[num1[i]] = true;
    }

    return pairs;
}
console.log(findPairsWithSum([1, 2, 3, 4, 5], 5));

//ques7
function sortByFrequency(num1) {
    let frequency = {};
    let result = [];

    for (let i = 0; i < num1.length; i++) {
        frequency[num1[i]] = (frequency[num1[i]] || 0) + 1;
    }

    for (let key in frequency) {
        result.push({ value: key, count: frequency[key] });
    }

    for (let i = 0; i < result.length - 1; i++) {
        for (let j = 0; j < result.length - i - 1; j++) {
            if (result[j].count < result[j + 1].count) {
                let temp = result[j];
                result[j] = result[j + 1];
                result[j + 1] = temp;
            }
        }
    }

    let sortedArray = [];
    for (let i = 0; i < result.length; i++) {
        for (let j = 0; j < result[i].count; j++) {
            sortedArray.push(Number(result[i].value));
        }
    }

    return sortedArray;
}
console.log(sortByFrequency([1, 1, 2, 2, 2, 3, 3, 4]));

//ques8
function generateSubarrays(num1) {
    let subarrays = [];
    for (let i = 0; i < num1.length; i++) {
        for (let j = i; j < num1.length; j++) {
            let subarray = [];
            for (let k = i; k <= j; k++) {
                subarray.push(num1[k]);
            }
            subarrays.push(subarray);
        }
    }
    return subarrays;
}
console.log(generateSubarrays([1, 2, 3]));

//ques9
function partitionArray(num1, pivot) {
    let left = [];
    let right = [];
    let equal = [];

    for (let i = 0; i < num1.length; i++) {
        if (num1[i] < pivot) {
            left.push(num1[i]);
        } else if (num1[i] > pivot) {
            right.push(num1[i]);
        } else {
            equal.push(num1[i]);
        }
    }

    return [...left, ...equal, ...right];
}
console.log(partitionArray([3, 5, 8, 2, 1, 4], 4));

//ques10
function productExceptSelf(num2) {
    let result = [];
    let n = num2.length;

    let prefixProduct = 1;
    for (let i = 0; i < n; i++) {
        result[i] = prefixProduct;
        prefixProduct *= num2[i];
    }

    let suffixProduct = 1;
    for (let i = n - 1; i >= 0; i--) {
        result[i] *= suffixProduct;
        suffixProduct *= num2[i];
    }

    return result;
}
console.log(productExceptSelf([1, 2, 3, 4]));