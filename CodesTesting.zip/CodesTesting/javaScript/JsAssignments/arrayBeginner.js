//ques1
let fruit = ["apple", "banana", "Cherry"];
fruit.forEach(fruit => console.log(fruit));

//ques2
let number = [1,2,3,4,5];
console.log(number[2])

//ques3
let color = ["yellow", "green", "red"];
color[1]="blue"
console.log(color)

//ques4
let num =[10,20,30,40,50]
console.log(num.length)