let str_single = 'string1'
let str_double ="string2"
let str_literal =`string3`
console.log(str_single);
console.log(str_double);
console.log(str_literal);

str1 = "Hi, ";
str2 = "Gunina!";
concatStrings = str1 + str2;
console.log(concatStrings);

str1 = "Hello Good morning"
console.log(str1.length)

str = "Hello";
first = str[0];
last = str[str.length - 1];
console.log(first + last);

str = "Hello";
console.log(str[0]);
console.log(str[str.length - 1]);

str = "Happy Birthday !";
a= str.toUpperCase();
b= str.toLowerCase();
console.log(a);
console.log(b);



// Intermediate Questions
//1
function literalTemp(name){
    return `My name is ${name}`;
}
result = literalTemp('Gunina')
console.log(result);
 
//2
function FirstandLast(strng, char){
    first = strng.indexOf(char)
    last = strng.lastIndexOf(char)
 
    return {first,last};
}
console.log(FirstandLast('Happy','p'));
 
// 3
function getstring(str,start,end){
    return str1  = str.substring(start,end)
}
console.log(getstring('lemonpieapple',2,8))
 
// 4
function replaceword(str,target,replacement){
    return str1 =  str.replace(target,replacement);
   
}
console.log(replaceword('My name is Gun','Gun','Gum.'));
 
// 5
function splitsentence(sentence){
    return sentence.split(" ")
}
console.log(splitsentence('Hello World'))
 