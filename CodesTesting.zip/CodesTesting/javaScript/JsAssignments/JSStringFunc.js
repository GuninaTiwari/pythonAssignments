//ques1
function trimString(str) {
    return str.trim();
}
console.log(trimString("   hello   "));

//ques2
function splitString(str, delimiter) {
    return str.split(delimiter);
}
console.log(splitString("hello,world", ","));

//ques3
function toUpperCaseString(str) {
    return str.toUpperCase();
}
console.log(toUpperCaseString("hello"));

//quues4
function toLowerCaseString(str) {
    return str.toLowerCase();
}
console.log(toLowerCaseString("HELLO"));