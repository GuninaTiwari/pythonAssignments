/*
    map function
    1) map() is array function in Javascript introduced in v6
    2) map() function used to modify and transform linear array 
    3) map() function default return value is "undefined"
    4) map() function has callback function which takes two arguments
            one is "item" and second is "index". "item" is an alise to reference each
            individual value of array and "index" is array position
    5) map() function will always return copy of updated array, there will no effect on
       origianal data
*/

let numbers = [18,45,34,45,76,46,99,56,34];

numbers.map(function(item,index){
    console.log(item + "   "  + index);
})

//Q1. increament each arary value by 10
var ans = numbers.map(function(item,index){
    return item+10;
})

var ans = numbers.map((item,index)=>{
    return item+10;
})

var ans = numbers.map((item,index)=>item+10);

var ans = numbers.map(item=>item+10);

console.log(ans);
console.log(numbers);

//Q2. increament only even numbers
var ans = numbers.map(function(item,index){
    if(item%2==0)
        return item;
})

console.log(ans);

//Q3. transform array in following sample output
//   output = [{position:0, value:18}, so on...]
var ans = numbers.map(function(item,index){
    return {position:index, value:item};
})

console.log(ans);