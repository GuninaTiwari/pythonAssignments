let numbers = [85,90,53,44,64,57,42];

//print only even numbers from array

//method-1
for(var i=0;i<numbers.length;i++)
{
    if(numbers[i]%2==0)
        console.log(numbers[i])
}


//method-2
var output = [];
for(var i=0;i<numbers.length;i++)
{
    if(numbers[i]%2==0)
        output.push(numbers[i])
}

//method-3
var output = [];
for(var i=0;i<numbers.length;i++)
{
    if(numbers[i]%2==0)
       output = [...output, numbers[i]]
}

//method-4
function filterEvenNumbers(data)
{
    var output = [];
    for(var i=0;i<data.length;i++)
    {
        if(data[i]%2==0)
            output.push(data[i])
    }    
    return output;
}

var output = [];
let filterEvenNumbers = numbers.filter(item=>item%2==0);

