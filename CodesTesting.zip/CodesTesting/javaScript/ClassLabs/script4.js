data = [
    {
        "id": 1,
        "name": "John Doe",
        "position": "Software Engineer",
        "department": "Development",
        "salary": 75000
    },
    {
        "id": 2,
        "name": "Jane Smith",
        "position": "Project Manager",
        "department": "Management",
        "salary": 85000
    },
    {
        "id": 3,
        "name": "Emily Johnson",
        "position": "UX Designer",
        "department": "Design",
        "salary": 70000
    },
    {
        "id": 4,
        "name": "Michael Brown",
        "position": "Data Analyst",
        "department": "Analytics",
        "salary": 72000
    },
    {
        "id": 5,
        "name": "Sarah Davis",
        "position": "QA Engineer",
        "department": "Quality Assurance",
        "salary": 68000
    }
]


//print employees whose name begins with J
var ans = data.filter(function(item,index){
    if(item.name[0]=="J")
        return item;
}).map(item=>item.name);

console.log(ans);

