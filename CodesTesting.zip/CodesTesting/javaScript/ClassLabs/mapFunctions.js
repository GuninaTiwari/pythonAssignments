/*
    map functions
    1) map() is array function in js introduced in v6
    2) map() function is used to modify and transform linear array
    3) map() function default return value is "undefined"
    4) map() function has callback function which takes two arguments
            one is item , 2nd is index , item is alise to reference each indiviual value
            of array & index is array position .
    5) map() function will always return copy of updated data 
*/ 

