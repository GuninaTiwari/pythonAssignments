// function circle(dim){
//     return 3.14*dim.rad*dim.rad;
// }
// function triangle(dim){
//     return 0.5*dim.base*dim.height;
// }

// function area(target,d){
//     target(d);
// }

// var area_c = area(circle,{rad:4.1});
// var area_t = area(triangle,{base:9.4,height :5.5});

// Correct code :
// ----------------------------
// var area_c = area((dim)=> 3.14*dim.rad*dim.rad,{rad:4.1});
// var area_t = area((dim)=> 0.5*dim.base*dim.height,{base:9.4,height :5.5});
// ----------------------------------


// function filterevenNumbers(data){
//     var output =[];
//     for (var i=0;i<data.length;i++)
//     {
//         if(data[i]%2==0)
//             output.push(data[i])
//     }
//     return output;   
// }


numbers=[10,20,333,35,6,46]
var output = [];
let filterevenNumbers = numbers.filter(item=>item%2==0);
console.log(filterevenNumbers)