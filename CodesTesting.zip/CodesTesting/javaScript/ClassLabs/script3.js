/*
    filter function
    1) filter() is array function in Javascript introduced in v6
    2) filter() function used to return only those array value which meets the condition criteria
    3) filter() function will never modify array value in any case
    3) filter() function default return value is []
    4) filter() function has callback function which takes two arguments
            one is "item" and second is "index". "item" is an alise to reference each
            individual value of array and "index" is array position
    5) filter() function will always return copy of updated array, there will no effect on
       original data
*/

let numbers = [18,45,34,45,76,46,99,56,34];

//Q1. increament each array value by 10
var ans = numbers.filter(function(item,index){
    return item;
});

console.log(ans);

//Q2. increase only even array values

//wrong approach
var ans = numbers.filter(function(item,index){
    if(item%2==0)
        item++;

    return item;
})

console.log(ans);

//right approach
var ans = numbers.filter(function(item,index){
    if(item%2==0)
        return item;
}).map(function(item,index){
    return item+1;
})

var ans = numbers.filter((item,index)=>{
    if(item%2==0)
        return item;
}).map((item,index)=>{
    return item+1;
})

var ans = numbers.filter(item=>item%2==0).map(item=>item+1);

console.log(ans);


