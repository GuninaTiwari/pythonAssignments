players = [
    {playerCode:1031, playerName:"Smith", innings:120, totalRuns:1400, grade:'India-A'},
    {playerCode:1010, playerName:"Peter", innings:110, totalRuns:1600, grade:'UK-A'},
    {playerCode:1836, playerName:"Nitin", innings:119, totalRuns:1250, grade:'India-B'},
    {playerCode:1841, playerName:"Kang", innings:170, totalRuns:1100, grade:'Austrellia-A'},
    {playerCode:9931, playerName:"John", innings:111, totalRuns:1730, grade:'Austrellia-B'},
    {playerCode:8481, playerName:"Smith", innings:109, totalRuns:1450, grade:'India-C'}
];


//Q1. define arrow function to print gradewise count of players
//    sample output: { A: 3, B: 2, C: 1 }
const gradewiseCount = players =>{
    let gradeCount ={};
    players.forEach(player =>{
        let gradeSuffix = player.grade.split('-')[1];
        if(!gradeCount[gradeSuffix]){
            gradeCount[gradeSuffix]=0;
        }
        gradeCount[gradeSuffix]++;
    });
    return gradeCount;
}
console.log(gradewiseCount(players));


//Q2. define function to print name of players in ascending orders
//	sample output : [ 'John', 'Kang', 'Nitin', 'Peter', 'Smith', 'Smith' ]
const getSortedPlayerNames = players =>{
    let names = players.map(player=> player.playerName);
    names.sort();
    return names;
}
console.log(getSortedPlayerNames(players));

//Q3. define function to print player-name who scored max runs and player-name who scored min runs
players = [
    {playerCode:1031, playerName:"Smith", innings:120, totalRuns:1400, grade:'India-A'},
    {playerCode:1010, playerName:"Peter", innings:110, totalRuns:1600, grade:'UK-A'},
    {playerCode:1836, playerName:"Nitin", innings:119, totalRuns:1250, grade:'India-B'},
    {playerCode:1841, playerName:"Kang", innings:170, totalRuns:1100, grade:'Austrellia-A'},
    {playerCode:9931, playerName:"John", innings:111, totalRuns:1730, grade:'Austrellia-B'},
    {playerCode:8481, playerName:"Smith", innings:109, totalRuns:1450, grade:'India-C'}
];

const findMaxMinRunScorers = player =>{
    if (players.length==0) return {maxRunScorer : null, minRunScorer:null};
    let maxRunScorer=players[0];
    let minRunScorer = players[0];
    for(let player of players){
        if(player.totalRuns> maxRunScorer.totalRuns){
            maxRunScorer=player;
        }
        if(player.totalRuns< minRunScorer.totalRuns){
            minRunScorer=player;
        }
    }
    return{maxRunScorer: maxRunScorer.playerName,minRunScorer:minRunScorer.playerName};

};
const{maxRunScorer,minRunScorer}=findMaxMinRunScorers(players);
console.log(`player with max runs: ${maxRunScorer}`);
console.log(`player with max runs: ${minRunScorer}`);

//Q4. define function to filter players whose innings are between 111 and 130
players = [
    {playerCode:1031, playerName:"Smith", innings:120, totalRuns:1400, grade:'India-A'},
    {playerCode:1010, playerName:"Peter", innings:110, totalRuns:1600, grade:'UK-A'},
    {playerCode:1836, playerName:"Nitin", innings:119, totalRuns:1250, grade:'India-B'},
    {playerCode:1841, playerName:"Kang", innings:170, totalRuns:1100, grade:'Austrellia-A'},
    {playerCode:9931, playerName:"John", innings:111, totalRuns:1730, grade:'Austrellia-B'},
    {playerCode:8481, playerName:"Smith", innings:109, totalRuns:1450, grade:'India-C'}
];
const filterPlayerByInnings = (players)=>{
    return players.filter(player=>player.innings >=111 && player.innings<=130);

}
const filterPlayers = filterPlayerByInnings(players);
console.log(filterPlayers);

//Q5. define arrow function to create array which collects players whose grades are from 'india'
players = [
    {playerCode:1031, playerName:"Smith", innings:120, totalRuns:1400, grade:'India-A'},
    {playerCode:1010, playerName:"Peter", innings:110, totalRuns:1600, grade:'UK-A'},
    {playerCode:1836, playerName:"Nitin", innings:119, totalRuns:1250, grade:'India-B'},
    {playerCode:1841, playerName:"Kang", innings:170, totalRuns:1100, grade:'Austrellia-A'},
    {playerCode:9931, playerName:"John", innings:111, totalRuns:1730, grade:'Austrellia-B'},
    {playerCode:8481, playerName:"Smith", innings:109, totalRuns:1450, grade:'India-C'}
];
const filterPlayersByGradeIndia = players =>
    players.filter(player=> player.grade.toLowerCase().includes('india'));
const indiaPlayers = filterPlayersByGradeIndia(players);
console.log(indiaPlayers);

//Q6. define function to find duplicates by name of player.
const findDuplicates = (players) =>{
    const nameCount = {};
    players.forEach(player => {
        nameCount[player.playerName]= (nameCount[player.playerName] ||0)+1;
    });
    const duplicates = players.filter(player=> nameCount[player.playerName]>1);
    const uniqueDuplicates = [...new Set(duplicates.map(player=> player.playerName ))];
    return uniqueDuplicates;
}
const duplicates = findDuplicates(players);
console.log(duplicates);