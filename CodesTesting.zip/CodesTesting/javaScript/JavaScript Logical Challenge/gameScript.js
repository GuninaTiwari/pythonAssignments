/* ques1 */
function enterRoom(){
    var roomtype = document.getElementById("typ").value;
var roomCode = parseInt(document.getElementById("code").value);

if ((roomtype =="Library" & roomCode =="2468") || (roomtype =="Dungeon" & roomCode =="7531") ){
    alert("Entering The Room !....");
} else if ((roomtype != "Library" || "Dungeon") & roomCode=="0000"){
    alert("Entering The Room !....")
} else{
    alert("Wrong Code or RoomType....")
}
}

/*ques 2 */

function billAmount(){
    var totalAmount = parseInt(document.getElementById("bill").value);
var people = parseInt(document.getElementById("peopleNum").value);
    if(totalAmount<= 50){
        var total = Number(totalAmount+((totalAmount*8)/100))+((totalAmount*15)/100)
        var each = total/people
        alert("Amount for each parson is"+ each)
    }

    if(totalAmount>= 50 & totalAmount<=100){
        var total = Number(totalAmount+((totalAmount*20)/100))
        var each = total/people
        alert("Amount for each parson is"+ each)
    }

    if(totalAmount>=100){
        var total = Number(totalAmount+((totalAmount*25)/100))
        var each = total/people
        alert("Amount for each parson is"+ each)
    }
}

//ques3
function planVacation() {
    let destination = "Paris"; // default destination
    if (document.getElementById('beach').checked) {
        destination = "Maldives, Bahamas, or Hawaii";
    } else if (document.getElementById('mountain').checked) {
        destination = "Switzerland, Colorado, or Nepal";
    } else if (document.getElementById('historical').checked) {
        destination = "Rome, Athens, or Cairo";
    }
    alert("Recommended destinations: " + destination);
}

//ques4
    function screening(){
        var qualification = (document.getElementById("qual").value);
        var experience = parseInt(document.getElementById("exp").value);
        
        if (qualification === "phd" && experience >= 5) {
            alert("Candidate accepted with Ph.D. and sufficient experience.");
        } else if (qualification === "masters" && experience >= 3) {
            alert("Candidate accepted with Master's and sufficient experience.");
        } else if (qualification === "bachelors" && experience >= 2) {
            alert("Candidate accepted with Bachelor's and sufficient experience.");
        } else {
            alert("Candidate does not meet the requirements.");
        }
    }
    