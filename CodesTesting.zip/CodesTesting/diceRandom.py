import random
roll = random.randint(1,6)
guess = int(input("Guess the number from 1 to 6: "))
if guess==roll :
    print("You guessed it right")
else :
    print("oh oh wrong guess ")
print("your number is " + str(roll))