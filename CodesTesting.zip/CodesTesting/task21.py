def find_pairs_of_numbers(nums, n):
    seen = set()
    count = 0
    
    for num in nums:
        target = n - num
        if target in seen:
            count += 1
        seen.add(num)
        
    return count

# Pytest test cases
def test_find_pairs_of_numbers():
    assert find_pairs_of_numbers([1, 2, 7, 4, 5, 6, 0, 3], 6) == 3
    assert find_pairs_of_numbers([3, 4, 1, 8, 5, 9, 0, 6], 9) == 4
    assert find_pairs_of_numbers([1, 2, 3, 4], 8) == 0  # No pairs
    assert find_pairs_of_numbers([], 5) == 0  # Empty list
    assert find_pairs_of_numbers([5], 5) == 0  # Single element
    assert find_pairs_of_numbers([10, 20, 30, 40, 50], 60) == 2  # Pairs (10,50) and (20,40)
    assert find_pairs_of_numbers([1, 1, 1, 1], 2) == 0  # No repetitions allowed

# To run the tests, use the following command in your terminal
# pytest <filename>.py
