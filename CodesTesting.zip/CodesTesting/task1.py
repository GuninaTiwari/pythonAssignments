distance = int(input("enter distance for one way :"))
mileage = int(input("enter mileage"))
Amount_per_litre = int(input("enter Amount_per_litre :"))
cost = ((( distance/mileage)* Amount_per_litre)/2)
print(cost)
if cost%5==0 :
   print("true")
else :
   print("false")
