solution = int(input("Enter x solution limit : "))
drinkAmount = int(input("Enter amount of drink needed : "))
if solution< drinkAmount :
    print("-1")
else :
    x = drinkAmount/4
    print("Ingredient A = ",3*x)
    print("Ingredient B = ",x)
