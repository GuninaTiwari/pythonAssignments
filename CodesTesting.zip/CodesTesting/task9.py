
day = int(input("Enter day: "))
month = int(input("Enter month: "))
year = int(input("Enter year: "))


if month < 1 or month > 12:
    print("Garbage Value")
    

elif (month == 2 and ((day > 29) or (day == 29 and not (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0))))):
    print("Garbage Value")
    
elif (month in [4, 6, 9, 11] and day > 30):
    print("Garbage Value")
    
elif (month in [1, 3, 5, 7, 8, 10, 12] and day > 31):
    print("Garbage Value")


else:
    if month == 12 and day == 31:
        print("1-1-", year + 1)
    elif day == 31:
        print("1-", month + 1, "-", year)
    elif month in [4, 6, 9, 11] and day == 30:
        print("1-", month + 1, "-", year)
    elif month == 2 and day == 28 and (year % 4 != 0 or (year % 100 == 0 and year % 400 != 0)):
        print("1-3-", year)
    else:
        print(day + 1, "-", month, "-", year)
