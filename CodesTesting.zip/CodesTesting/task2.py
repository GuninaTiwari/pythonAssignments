principal = int(input("Enter principal : "))
roi = float(input("Enter roi : "))
time = int(input("Enter time : "))
SI = (principal*roi*time)/100
print(SI)
