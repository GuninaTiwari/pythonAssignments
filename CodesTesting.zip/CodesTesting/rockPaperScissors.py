import random
#seq =["scissors","rock","paper"]
computer_choice = random.choice(['scissors','rock','paper'])
userChoice = input("Enter users choice : ")
print(computer_choice)
if userChoice == computer_choice :
    print("Tie")
elif (userChoice == "rock" and computer_choice== "scissors") :
    print("YOU WIN!")
elif (userChoice == "scissors" and computer_choice== "paper"):
    print("YOU WIN!")
elif (userChoice=="paper" and computer_choice=="rock") :
    print("YOU WIN!")
elif (computer_choice == "rock" and userChoice== "scissors"):
    print("YOU LOSE")
elif (computer_choice == "scissors" and userChoice== "paper"):
    print("YOU LOSE")
elif (computer_choice=="paper" and userChoice=="rock") :
    print("YOU LOSE")
else :
    print("WRONG INPUT")
