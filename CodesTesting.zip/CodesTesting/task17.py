def run_length_encoding(s):
    if not s:  
        return ""

    encoded_string = []
    count = 1  

    for i in range(1, len(s)):
        if s[i] == s[i - 1]:
            count += 1 
        else:
        
            encoded_string.append(str(count)+s[i - 1] )
            count = 1 

    encoded_string.append(str(count)+s[-1] )

    return ''.join(encoded_string)


print(run_length_encoding("AAABBBCCDAA"))  
print(run_length_encoding("CCCCCC"))        
print(run_length_encoding("AABBC"))        
print(run_length_encoding("XYZ"))          
print(run_length_encoding(""))               
