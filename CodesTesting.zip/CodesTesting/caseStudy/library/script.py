

def showMenus(menus):
    if type(menus) == list:
        for item in menus:
            print("%20s %20s %10d %10s"%(item['code'],item['itemname'],item['price'],item['stock']))


def makeOrder(menus):
    customerOrder = input("Describe your order <menucode> <qty> :")
    #"M801 3, M804 2, M701 5"

    if type(menus) == list:
        codeList = [item['code'] for item in menus]
        co = [item.split(" ") for item in customerOrder.split(",")]
        #['M801 3', 'M804 2','M701 5'] -> [['M801','3'], ['M804', '2'],['M701', '5']]



        tempOrderList = list()
        for orderItem in co:
            d = dict()
            d['code'] = orderItem[0]
            d['qty'] = int(orderItem[1])

            if d['code'] in codeList:
                d['status'] = 'valid'
                print('Menu ',d['code'],'created order successfully')
            else:
                d['status'] = 'invalid'
                print('Menu ',d['code'],'not exist. try again')

            tempOrderList.append(d)

        print(tempOrderList)
        orderCount = 0
        if input("do you want to process this order [y/n]? :") == 'y':
            #return tempOrderList
            orderCount=+1
            #print(f"{"orderno :"}",{orderCount},{",Menus["},(tempOrderList),"]")
        else:
            if input('modify/cancel order [m/c] ?') == 'm':
                for eachItem in tempOrderList:
                    print("%20s %10d %10s"%(eachItem['code'],eachItem['qty'],eachItem['status']))

                    qty = int(input("Enter new Qtys :"))
                    eachItem['qty'] = qty

            else:
                print("Thanks! have a great day.")
                return