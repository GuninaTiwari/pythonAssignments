distance = float(input("Enter the distance of the route (in km): "))
passengers = int(input("Enter the number of passengers: "))

def calculate_profit_loss(distance, passengers):
    price_per_litre = 70
    mileage = 10
    price_per_ticket = 80

    fuel_needed = distance / mileage
    total_fuel_cost = fuel_needed * price_per_litre

    total_revenue = passengers * price_per_ticket

    profit_loss = total_revenue - total_fuel_cost

    if profit_loss > 0:
        return f"The route is running at a profit of Rs {profit_loss:.2f}."
    elif profit_loss < 0:
        return f"The route is running at a loss of Rs {abs(profit_loss):.2f}."
    else:
        return "The route is breaking even."

result = calculate_profit_loss(distance, passengers)
print(result)
