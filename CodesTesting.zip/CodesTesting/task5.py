Joblevel = int(input("Enter job level : "))
if Joblevel!=3 and Joblevel!=4 and Joblevel!=5 :
	print("Invalid job level , hike 0%")
else :
	Current_salary = int(input("Enter current salary : "))
	if Joblevel ==3 :
		new_salary = ((Current_salary*15)/100)+ Current_salary
		print(new_salary)
	elif Joblevel==4:
		new_salary = ((Current_salary*7)/100)+ Current_salary
		print(new_salary)
		
	elif Joblevel ==5 :
		new_salary = ((Current_salary*5)/100)+ Current_salary
		print(new_salary)
	   



