def solve_chickens_rabbits(heads, legs):
    r = (legs - 2 * heads) / 2
    c = heads - r
    if r < 0 or c < 0 or r % 1 != 0 or c % 1 != 0:
        return None, None
    return int(c), int(r)

heads = int(input("Enter the number of heads: "))
legs = int(input("Enter the number of legs: "))

chickens, rabbits = solve_chickens_rabbits(heads, legs)

if chickens is not None and rabbits is not None:
    print(f"There are {chickens} chickens and {rabbits} rabbits.")
else:
    print("No valid solution exists with the given heads and legs.")
