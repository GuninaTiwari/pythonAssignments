#numbers = [19,45,-9,43,-88,100,45]
numbers = input("Enter list : ")
list =numbers.split(',')
#for loop
positive_count = 0
negative_count = 0
for i in list :
    if int(i)>0 :
        positive_count+=1
    else :
        negative_count+=1
print("No. of positive no.s : ", positive_count)
print("No. of positive no.s : ", negative_count)

#list comprehension
#positive_count = len([num for num in numbers if num>0])
#negative_count = len([num for num in numbers if num<0])

# print("Positive no : ", positive_count)
# print("Negative no : ", negative_count)