'''class Employee :
    empid =193
    empname ="Smith"
    salary = 10000


e1 = Employee()
e2 = Employee()
e3 = Employee()

e3.empid = 100
e3.empname ="Peter"
e3.salary =50000
e3.role = "Manager"

print(e3)'''
'''
class Employee :
    pass
e1 = Employee()
e1.id =43
e1.name = "James"

e2 = Employee()
e2.role ="Manager"
e2.location = "India"

e3 = Employee()
e3.id ="234"
e3.email = "smith@gmail.com"
'''

class Employee :
    def add(self,id,name,salary,location):
        self.id = id
        self.name = name
        self.salary = salary
        self.location = location

    def show(self):
        print(self.id,self.name,self.salary,self.location)

e1 = Employee()
e1.add(101,"smith",10000,"India")

e2 = Employee()
e2.add(102,"mith",20000,"India")

e3 = Employee()
e3.add(103,"luise",20000,"India")

e1.show()
e2.show()
e3.show()
