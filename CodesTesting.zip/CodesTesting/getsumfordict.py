#get sum of amount of all products 
products = [    [101, "Mouse", "INR 1000", True],   
 [102, "Keyboard", "INR 4000", True],    
 [103, "Speaker", "INR 3700", True],    
 [104, "Motherboard", "INR 2900", False],    
 [105, "Bluetooth", "INR 900", True],
 ]

#for i in range(len(products)):    products[i][1]=products[i][1].upper()
# to print product name in capitalS
for n in range(0,len(products)):    
    print (products[n][1])
'''
for n in range(0,len(products)):    
    #print (products[n][1].upper())
    del(products[0])
    print(products)
'''


#Ques : Add tax amt 5% of product cost at the
# end of nested list 

for item in products:
    amount = int(item[2].split()[1])
    tax = amount*0.05
 
    item.append(tax)
 
print(products)