from math import ceil


students = int(input("Enter no. of students : "))
if students <=100 :
    print("Total transportation cost : rs 2000")
else :
    cost = ceil(students/100)*2000
    print("Total transportation cost :",cost)

if students<=150 :
    snacks = students*50
    print("Total snacks cost : ",snacks)
else :
    snacks = students*40
    print("Total snacks cost : ",snacks)
