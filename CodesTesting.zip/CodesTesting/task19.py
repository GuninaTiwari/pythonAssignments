def most_visited_specialty(patient_visits):
    specialties = {
        "P": "Pediatrics",
        "O": "Orthopedics",
        "E": "ENT"
    }

    visit_count = {"P": 0, "O": 0, "E": 0}

    for i in range(1, len(patient_visits), 2):  # start from 1 and step by 2
        specialty_code = patient_visits[i]
        if specialty_code in visit_count:
            visit_count[specialty_code] += 1

    max_specialty_code = max(visit_count, key=visit_count.get)

    return specialties[max_specialty_code]

if __name__ == "__main__":
   
    input_data = input("Enter patient visits (e.g., 101,P,102,O,302,P,305,P): ")
    
    patient_visits = input_data.split(',')

    result = most_visited_specialty(patient_visits)
    print(f"The medical specialty visited by the maximum number of patients is: {result}")
