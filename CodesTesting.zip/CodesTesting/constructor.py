#init and str function

class Passenger:
    
    def __init__(self, firstname, lastname, age, gender):
        self.firstname = firstname
        self.lastname = lastname
        self.age = age
        self.gender = gender

    def __str__(self):
        return f"{self.firstname} {self.lastname} {self.age} {self.gender}"

class Flight:
    passengers_list = list()
    
    def __init__(self, passenger, flightname, ticketcost):
        self.passenger = passenger
        self.flightname = flightname
        self.ticketcost = ticketcost
        
        self.passengers_list.append(self)

    def __str__(self):
        return f"{self.passenger} \t {self.flightname} \t {self.ticketcost}"

        
p1 = Passenger("james", "devid", 29, "male")
p2 = Passenger("peter", "mathew", 48, "male")

first_flight = Flight(p1, "INDIGO", 5000.00)
second_flight = Flight(p2, "AIR INDIA", 7000.00)


for item in Flight.passengers_list:
    print(item)


#Assignment: Compare condition for passengers in a passenger list, who is elder.

#method1
if p1.age< p2.age:
    print("P2 is elder")
elif p2.age< p1.age:
    print("P1 is elder")
else :
    print("Both are of same age")

#method2
x =max(p1.age,p2.age)
print(x ,"is the oldest age of passenger onboarding")



