# age = int(input("What is your age?"))
# print("You are ",age//10 , "decades and ",age%10, " years old")

raining = True
if not raining :
    print("Go outside")
else :
    print("stay inside")