# Sample inventory of gems with prices
gem_inventory = {
    "Ruby": 5000,
    "Emerald": 7000,
    "Sapphire": 6000,
    "Diamond": 12000,
    "Opal": 4500
}

# Input from user
purchases = {}
while True:
    gem = input("Enter the gem name (or 'done' to finish): ")
    if gem.lower() == 'done':
        break
    quantity = int(input(f"Enter quantity for {gem}: "))
    purchases[gem] = quantity

def calculate_bill(purchases):
    total_amount = 0
    
    for gem, quantity in purchases.items():
        if gem not in gem_inventory:
            return -1  # Gem not available
        total_amount += gem_inventory[gem] * quantity

    # Apply discount if total amount is greater than Rs.30000
    if total_amount > 30000:
        total_amount *= total_amount*0.95  # Apply 5% discount

    return total_amount

# Calculate bill
bill_amount = calculate_bill(purchases)

# Display result
if bill_amount == -1:
    print("One or more gems are not available in the store.")
else:
    print(f"The total bill amount is: Rs. {bill_amount:.2f}")
