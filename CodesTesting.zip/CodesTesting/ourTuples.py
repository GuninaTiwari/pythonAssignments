'''
you cant put set into set because it is unhashable

`[p]`

theres no remove keyword in dict
you cant access index in dict

set doesnt have repeated data , to remove redundancy put data into set

OAAR Tool for monthly internet bill after training
'''