def common_characters(str1, str2):
    str1 = str1.replace(" ", "")
    str2 = str2.replace(" ", "")
   
    common_chars = set(str1) & set(str2)
   
    if common_chars:
        return ''.join(sorted(common_chars))
    else:
        return -1

if __name__ == "__main__":
    
    input_str1 = input("write string 1 : ")
    input_str2 = input("write string 2 : ")
    result = common_characters(input_str1, input_str2)
    print(result)  
