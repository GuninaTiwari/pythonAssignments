
num1 = int(input("Enter num1: "))
num2 = int(input("Enter num2: "))

def find_maximum(num1, num2):
    if num1 >= num2:
        return -1 

    valid_numbers = [] 
    for num in range(num1, num2):
        if 10 <= num < 100:
            if num % 5 == 0:
                digit_sum = sum(int(d) for d in str(num))
                if digit_sum % 3 == 0:
                    valid_numbers.append(num)  

    if valid_numbers:
        return max(valid_numbers)
    else:
        return -1  

print(find_maximum(num1, num2))

