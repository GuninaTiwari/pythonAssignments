accno =0
accname =" "
opening_balance =0

def addAccount() :
    accno = int(input("Enter account number :"))
    accname = input("Enter account holder name :")
    opening_balance = float(input("Enter opening balance :"))
    print("Account created succesfully")

def showAcc():
    an = int(input("Enter account number to see details :"))
    if an==accno:
        print("%10d %20s %10.2f"%(accno, accname, opening_balance))
    else:
        print("invalid account")

def depositMoney() :
    an = int(input("Enter account number to deposit money :"))
    if an == accno:
        damt = float(input("Enter amount :"))
        opening_balance+=damt
        print("Amount Rs.",damt," credited to account number ", an)
    else :
        print("invalid account")


def withdrawAmount() :
    an = int(input("Enter account number to withdraw money :"))
    if an == accno:
            wamt = float(input("Enter amount :"))
            if wamt<=opening_balance:
                opening_balance -= wamt
                print("Amount Rs.", wamt, " debited from account number ", an)
            else:
                print("less balance.")
    else:
        print("invalid account")

def searchAccount():
    pass
    

def createAccount() :
    accno = int(input("Enter acc no. :"))
    accname= input("enter acc holder name : ")
    opening_balance = float(input("Enter opening balance : "))
    return True


   