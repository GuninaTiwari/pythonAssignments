#wap to Create list of numbers and 
# write condition to saperate even numbers and show output

numbers = [1,2,3,5,6,7]
for i in numbers :
    if i%2==0 :
      print(i)