const express = require("express");
const bodyParser = require("body-parser");
const axios = require("axios");
 
const app = express();
const PORT = 3999;
 
// Middleware
app.use(bodyParser.json());
 
// Flask Server URL
const FLASK_SERVER_URL = "http://127.0.0.1:2999/login";
 
// POST /signin - Node.js endpoint that connects to Flask API
app.post("/signin", async (req, res) => {
  try {
    // Forward the request body to the Flask API
    const response = await axios.post(FLASK_SERVER_URL, req.body);
 
    // Return the response from Flask back to the client
    res.status(response.status).json(response.data);
  } catch (error) {
    console.error("Error connecting to Flask server:", error.message);
 
    // Handle errors (Flask server might be down or return an error)
    if (error.response) {
      res.status(error.response.status).json(error.response.data);
    } else {
      res.status(500).json({ message: "Unable to connect to Flask server" });
    }
  }
});
 
// Start the server
 
app.listen(PORT, () => {
  console.log(`Node.js server running on http://localhost:${PORT}`);
});
 
 