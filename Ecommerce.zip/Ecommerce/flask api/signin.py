from flask import Flask, request, jsonify
from flask_mysqldb import MySQL
from flask_jwt_extended import JWTManager, create_access_token, get_jwt_identity, jwt_required
import MySQLdb
from dotenv import load_dotenv
import os
import json  # Import json to handle dictionary serialization
 
# Load environment variables
load_dotenv()
app = Flask(__name__)
 
# MySQL Configuration
app.config['MYSQL_HOST'] = os.getenv('MYSQL_HOST')
app.config['MYSQL_USER'] = os.getenv('MYSQL_USER')
app.config['MYSQL_PASSWORD'] = os.getenv('MYSQL_PASSWORD')
app.config['MYSQL_DB'] = os.getenv('MYSQL_DB')
mysql = MySQL(app)
 
# JWT Configuration
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY')  # Use a strong secret key from .env
jwt = JWTManager(app)
 
# Login API
@app.route('/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')
 
    # Validate input
    if not email or not password:
        return jsonify({'error': 'Email and password are required!'}), 400
 
    try:
        # Query user from database
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("""
            SELECT id, email, password,
            DATE_FORMAT(created_at, '%%d-%%M-%%Y') AS created_at
            FROM users WHERE email = %s AND password = %s
        """, (email, password))
        user = cursor.fetchone()
        cursor.close()
 
        # Check if user exists and password matches
        if not user:
            return jsonify({'error': 'Invalid email or password!'}), 401
 
        # Serialize user identity into a string using json.dumps
        user_identity = json.dumps({'id': user['id'], 'email': user['email']})
 
        # Generate JWT token
        access_token = create_access_token(identity=user_identity)
 
        # Include all user details in the response
        response = {
            'message': 'Login successful!',
            'id': user['id'],
            'email': user['email'],
            'created_at': user['created_at'],
            'access_token': access_token
        }
 
        return jsonify(response), 200
 
    except Exception as e:
        return jsonify({'error': f"Database error: {str(e)}"}), 500
 
# Token Validation API
@app.route('/auth/validate', methods=['POST'])
@jwt_required()  # Protects this route, requiring a valid token
def validate_token():
    try:
        # Get the identity of the currently authenticated user
        # current_user = json.loads(get_jwt_identity())  # Deserialize the user identity
 
        # Return a success message along with user details
        return jsonify({
            'message': 'Success',
        }), 200
 
    except Exception as e:
        return jsonify({'message': 'Invalid token', 'error': str(e)}), 401


# @app.route('/auth/validate', methods=['POST'])
# @jwt_required()  # Protects this route, requiring a valid token
# def validate_token():
#     try:
#         # Get the identity of the currently authenticated user
#         current_user = get_jwt_identity()  # Get the user identity
        
#         # Return a success message
#         return jsonify({
#             'message': 'Success',
#         }), 200

#     except JWTExtendedException as e:
#         # Handle specific JWT exceptions
#         return jsonify({'message': 'failed , error : Access forbidden'}), 401

#     except Exception as e:
#         # Handle any other exceptions
#         return jsonify({'message': 'failed , error : Access forbidden'}), 401

    
#post
@app.route('/orders', methods=['POST'])
@jwt_required()
def create_order():
    data = request.get_json()
    customer_id = data.get('customer_id')
    shipping_address = data.get('shipping_address')

    if not customer_id or not shipping_address:
        return jsonify({'error': 'Customer ID and shipping address are required!'}), 400

    try:
        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO orders (customer_id, shipping_address) VALUES (%s, %s)",
                       (customer_id, shipping_address))
        mysql.connection.commit()
        order_id = cursor.lastrowid
        cursor.close()

        return jsonify({'message': 'Order created successfully', 'order_id': order_id}), 201
    except MySQLdb.Error as e:
        return jsonify({'error': str(e)}), 500


# @app.route('/orders',methods = ['POST'])
# @jwt_required()
# def orders():

#     cursor = mysql.connection.cursor()
#     customer_id = request.json.get('customer_id')
#     shipping_address=request.json.get('shipping_address')
#     cursor.execute({"insert into orders (customer_id,shipping_address) values(%s,%s)",(customer_id,shipping_address)})
#     cursor.commit()
#     mysql.connection.commit()

#     if not customer_id or not shipping_address:
#       return jsonify({"message":"not created"}),400
#     return jsonify({"message":"order created suucessfully"}),200


# @app.route('/orders/<int:order_id>', methods=['GET'])
# @jwt_required()
# def get_order(order_id):
#     try:
#         cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
#         cursor.execute("select * from orders",(order_id))
#         order = cursor.fetchone()
#         cursor.close()

#         if not order:
#             return jsonify({'message': 'Order not found'}), 404

#         return jsonify({
#             'order_id': order['order_id'],
#             'customer_id': order['customer_id'],
#             'shipping_address': order['shipping_address'],
#             'order_status': order['order_status'],
#             'items': json.loads(order['items'])
#         }), 200

#     except Exception as e:
#         return jsonify({'message': 'Internal server error', 'error': str(e)}), 500


@app.route('/orders/<int:order_id>', methods=['GET'])
@jwt_required()
def get_order(order_id):
    # x =[{"id" : 21,"value" :"monitor"}, {"id" : 22,"value" :"keyboard"}, {"id" : 23,"value" :"mouse"},{"id" : 24,"value" :"cpu"}]
    
    try:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("""
            SELECT 
                o.order_id AS order_id, 
                o.customer_id, 
                o.shipping_address, 
                o.order_status,
                JSON_ARRAYAGG(JSON_OBJECT(
                    'product_id', oi.product_id, 
                    'quantity', oi.quantity
                )) AS items
            FROM orders o
            LEFT JOIN order_items oi ON o.order_id = oi.order_id
            WHERE o.order_id = %s
            GROUP BY o.order_id
        """, (order_id,))
        order = cursor.fetchone()
        cursor.close()

        if not order:
            return jsonify({'message': 'Order not found'}), 404
        items = json.loads(order['items'])


        return jsonify({
            'order_id': order['order_id'],
            'customer_id': order['customer_id'],
            'shipping_address': order['shipping_address'],
            'order_status': order['order_status'],
            'items': json.loads(order['items']),
            # 'x' : x
        }), 200

    except Exception as e:
        return jsonify({'message': 'Internal server error', 'error': str(e)}), 500
    
@app.route('/customers/<string:customer_id>/orders', methods=['GET'])
@jwt_required()
def get_customer_orders(customer_id):
    try:
        # Query orders for the given customer_id
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("""
            SELECT 
                o.order_id AS order_id, 
                o.shipping_address, 
                o.order_status
            FROM orders o
            WHERE o.customer_id = %s
        """, (customer_id,))
        orders = cursor.fetchall()
        cursor.close()

        if not orders:
            return jsonify({'message': 'No orders found for this customer'}), 404

        # Prepare the response structure
        order_data = []
        for order in orders:
            order_data.append({
                'order_id': order['order_id'],
                'shipping_address': order['shipping_address'],
                'order_status': order['order_status']
            })

        return jsonify({
            'orders': order_data
        }), 200

    except Exception as e:
        return jsonify({'message': 'Internal server error', 'error': str(e)}), 500

@app.route('/products/<string:product_id>', methods=['GET'])
@jwt_required()
def get_product(product_id):
    try:
        # Query product details for the given product_id
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

        cursor.execute("""
            SELECT 
                product_id AS product_id, 
                product_name, 
                category, 
                price, 
                stock_quantity
            FROM products
            WHERE product_id = %s
        """, (product_id,))
        product = cursor.fetchone()
        cursor.close()

        if not product:
            return jsonify({'message': 'Product not found'}), 404

        return jsonify({
            'product_id': product['product_id'],
            'product_name': product['product_name'],
            'category': product['category'],
            'price': product['price'],
            'stock_quantity': product['stock_quantity']
        }), 200

    except Exception as e:
        return jsonify({'message': 'Internal server error', 'error': str(e)}), 500

@app.route('/orders/<int:order_id>/status', methods=['PUT'])
@jwt_required()
def update_order_status(order_id):
    if request.content_type != 'application/json':
        return jsonify({'message': 'Content-Type must be application/json'}), 415

    try:
        data = request.json
        order_status = data.get('order_status')

        if not order_status:
            return jsonify({'message': 'Order status is required'}), 400

        cursor = mysql.connection.cursor()
        cursor.execute("""
            UPDATE orders
            SET order_status = %s
            WHERE order_id = %s
        """, (order_status, order_id))
        mysql.connection.commit()
        cursor.close()

        return jsonify({
            'message': 'Order status updated successfully',
            'order_id': order_id,
            'order_status': order_status
        }), 200

    except Exception as e:
        return jsonify({'message': 'Internal server error', 'error': str(e)}), 500

@app.route('/products/<string:product_id>', methods=['DELETE'])
@jwt_required()
def delete_product(product_id):
    try:
        cursor = mysql.connection.cursor()

        # Delete the product (this will also delete related records in order_items due to the cascading delete)
        cursor.execute("DELETE FROM products WHERE product_id = %s", (product_id,))
        mysql.connection.commit()
        cursor.close()

        if cursor.rowcount == 0:
            return jsonify({'message': 'Product not found'}), 404

        return jsonify({'message': 'Product deleted successfully'}), 200

    except Exception as e:
        return jsonify({'message': 'Internal server error', 'error': str(e)}), 500

@app.route('/payments/<int:payment_id>', methods=['GET'])
@jwt_required()
def get_payment(payment_id):
    try:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("""
            SELECT 
                payment_id, 
                order_id, 
                amount, 
                payment_method, 
                payment_date
            FROM payments
            WHERE payment_id = %s
        """, (payment_id,))
        payment = cursor.fetchone()
        cursor.close()

        if not payment:
            return jsonify({'message': 'Payment not found'}), 404

        return jsonify({
            'payment_id': payment['payment_id'],
            'order_id': payment['order_id'],
            'amount': payment['amount'],
            'payment_method': payment['payment_method'],
            'payment_date': payment['payment_date']
        }), 200

    except Exception as e:
        return jsonify({'message': 'Internal server error', 'error': str(e)}), 500

# @app.route('/products/<int:product_id>', methods=['DELETE'])
# @jwt_required()
# def delete_product(product_id):
#     try:
#         cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
       
#         # Check if the product exists
#         cursor.execute("SELECT * FROM products WHERE product_id = %s", (product_id,))
#         product = cursor.fetchone()
#         if not product:
#             return jsonify({'message': 'Product not found'}), 404
       
#         # Attempt to delete the product
#         cursor.execute("DELETE FROM products WHERE product_id = %s", (product_id,))
#         mysql.connection.commit()
#         cursor.close()
       
#         return jsonify({'message': 'Product deleted successfully'}), 200
   
#     # except MySQLdb.IntegrityError as e:
#     #     # Handle foreign key constraints
#     #     return jsonify({'error': 'Cannot delete product due to associated references', 'details': str(e)}), 409
   
#     except Exception as e:
#         # Handle other errors
#         return jsonify({'error': 'An error occurred', 'details': str(e)}), 500
if __name__ == '__main__':
    app.run(debug=True, port=2999)
 