-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: leave_management
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `department_id` int NOT NULL AUTO_INCREMENT,
  `department_name` varchar(100) DEFAULT NULL,
  `manager_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'HR',1,'2024-11-14 09:50:30'),(2,'Finance',2,'2024-11-14 09:50:30'),(3,'Engineering',3,'2024-11-14 09:50:30'),(4,'Marketing',4,'2024-11-14 09:50:30'),(5,'Sales',5,'2024-11-14 09:50:30');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_contacts`
--

DROP TABLE IF EXISTS `employee_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_contacts` (
  `contact_id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int DEFAULT NULL,
  `contact_name` varchar(100) DEFAULT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`contact_id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `employee_contacts_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_contacts`
--

LOCK TABLES `employee_contacts` WRITE;
/*!40000 ALTER TABLE `employee_contacts` DISABLE KEYS */;
INSERT INTO `employee_contacts` VALUES (1,1,'Mary Doe','Spouse','9876543210','123 Elm St','2024-11-14 09:50:30'),(2,2,'David Smith','Brother','8765432109','456 Oak St','2024-11-14 09:50:30'),(3,3,'Paul Johnson','Father','7654321098','789 Pine St','2024-11-14 09:50:30');
/*!40000 ALTER TABLE `employee_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `employee_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `profile_picture` blob,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`employee_id`),
  KEY `department_id` (`department_id`),
  CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'John','Doe','1990-01-15','2020-02-01',1,'john.doe@example.com','1234567890',NULL,'2024-11-14 09:50:30'),(2,'Jane','Smith','1985-07-10','2019-03-15',2,'jane.smith@example.com','2345678901',NULL,'2024-11-14 09:50:30'),(3,'Sam','Johnson','1987-05-22','2018-08-10',3,'sam.johnson@example.com','3456789012',NULL,'2024-11-14 09:50:30'),(4,'Emily','Davis','1993-12-02','2021-04-05',4,'emily.davis@example.com','4567890123',NULL,'2024-11-14 09:50:30'),(5,'Michael','Brown','1988-11-17','2017-07-18',5,'michael.brown@example.com','5678901234',NULL,'2024-11-14 09:50:30');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_allocations`
--

DROP TABLE IF EXISTS `leave_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_allocations` (
  `allocation_id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int DEFAULT NULL,
  `leave_type_id` int DEFAULT NULL,
  `allocated_days` int DEFAULT NULL,
  `year` int DEFAULT NULL,
  `used_days` int DEFAULT '0',
  `balance_days` int GENERATED ALWAYS AS ((`allocated_days` - `used_days`)) STORED,
  PRIMARY KEY (`allocation_id`),
  KEY `employee_id` (`employee_id`),
  KEY `leave_type_id` (`leave_type_id`),
  CONSTRAINT `leave_allocations_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`),
  CONSTRAINT `leave_allocations_ibfk_2` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`leave_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_allocations`
--

LOCK TABLES `leave_allocations` WRITE;
/*!40000 ALTER TABLE `leave_allocations` DISABLE KEYS */;
INSERT INTO `leave_allocations` (`allocation_id`, `employee_id`, `leave_type_id`, `allocated_days`, `year`, `used_days`) VALUES (1,1,1,12,2024,0),(2,1,2,20,2024,0),(3,2,3,10,2024,0),(4,3,4,90,2024,0),(5,4,5,10,2024,0);
/*!40000 ALTER TABLE `leave_allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_approvals`
--

DROP TABLE IF EXISTS `leave_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_approvals` (
  `approval_id` int NOT NULL AUTO_INCREMENT,
  `request_id` int DEFAULT NULL,
  `manager_id` int DEFAULT NULL,
  `approval_status` varchar(20) DEFAULT NULL,
  `approval_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`approval_id`),
  KEY `request_id` (`request_id`),
  KEY `manager_id` (`manager_id`),
  CONSTRAINT `leave_approvals_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `leave_requests` (`request_id`),
  CONSTRAINT `leave_approvals_ibfk_2` FOREIGN KEY (`manager_id`) REFERENCES `employees` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_approvals`
--

LOCK TABLES `leave_approvals` WRITE;
/*!40000 ALTER TABLE `leave_approvals` DISABLE KEYS */;
INSERT INTO `leave_approvals` VALUES (1,1,2,'Approved','2024-11-14 09:50:30'),(2,2,3,'Pending','2024-11-14 09:50:30'),(3,3,4,'Denied','2024-11-14 09:50:30'),(4,4,1,'Approved','2024-11-14 09:50:30'),(5,5,2,'Approved','2024-11-14 09:50:30');
/*!40000 ALTER TABLE `leave_approvals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_documents`
--

DROP TABLE IF EXISTS `leave_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_documents` (
  `document_id` int NOT NULL AUTO_INCREMENT,
  `request_id` int DEFAULT NULL,
  `document_type` varchar(50) DEFAULT NULL,
  `document_content` blob,
  `uploaded_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`document_id`),
  KEY `request_id` (`request_id`),
  CONSTRAINT `leave_documents_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `leave_requests` (`request_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_documents`
--

LOCK TABLES `leave_documents` WRITE;
/*!40000 ALTER TABLE `leave_documents` DISABLE KEYS */;
INSERT INTO `leave_documents` VALUES (1,1,'Medical Certificate',NULL,'2024-11-14 09:50:30'),(2,2,'Vacation Plan',NULL,'2024-11-14 09:50:30'),(3,3,'Sick Note',NULL,'2024-11-14 09:50:30');
/*!40000 ALTER TABLE `leave_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_entitlement`
--

DROP TABLE IF EXISTS `leave_entitlement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_entitlement` (
  `entitlement_id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int DEFAULT NULL,
  `leave_type_id` int DEFAULT NULL,
  `entitlement_year` int DEFAULT NULL,
  `total_entitlement` int DEFAULT NULL,
  `used_entitlement` int DEFAULT '0',
  `remaining_entitlement` int GENERATED ALWAYS AS ((`total_entitlement` - `used_entitlement`)) STORED,
  PRIMARY KEY (`entitlement_id`),
  KEY `employee_id` (`employee_id`),
  KEY `leave_type_id` (`leave_type_id`),
  CONSTRAINT `leave_entitlement_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`),
  CONSTRAINT `leave_entitlement_ibfk_2` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`leave_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_entitlement`
--

LOCK TABLES `leave_entitlement` WRITE;
/*!40000 ALTER TABLE `leave_entitlement` DISABLE KEYS */;
INSERT INTO `leave_entitlement` (`entitlement_id`, `employee_id`, `leave_type_id`, `entitlement_year`, `total_entitlement`, `used_entitlement`) VALUES (1,1,1,2024,12,0),(2,1,2,2024,20,0),(3,2,3,2024,10,0),(4,3,4,2024,90,0),(5,4,5,2024,10,0);
/*!40000 ALTER TABLE `leave_entitlement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_history`
--

DROP TABLE IF EXISTS `leave_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_history` (
  `history_id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int DEFAULT NULL,
  `leave_type_id` int DEFAULT NULL,
  `leave_days` int DEFAULT NULL,
  `leave_date` date DEFAULT NULL,
  `action_taken` varchar(100) DEFAULT NULL,
  `action_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`history_id`),
  KEY `employee_id` (`employee_id`),
  KEY `leave_type_id` (`leave_type_id`),
  CONSTRAINT `leave_history_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`),
  CONSTRAINT `leave_history_ibfk_2` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`leave_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_history`
--

LOCK TABLES `leave_history` WRITE;
/*!40000 ALTER TABLE `leave_history` DISABLE KEYS */;
INSERT INTO `leave_history` VALUES (1,1,1,5,'2024-02-05','Approved','2024-11-14 09:50:30'),(2,2,2,7,'2024-03-10','Pending','2024-11-14 09:50:30'),(3,3,3,3,'2024-04-17','Denied','2024-11-14 09:50:30'),(4,4,4,10,'2024-08-10','Approved','2024-11-14 09:50:30'),(5,5,5,5,'2024-06-05','Approved','2024-11-14 09:50:30');
/*!40000 ALTER TABLE `leave_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_requests`
--

DROP TABLE IF EXISTS `leave_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_requests` (
  `request_id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int DEFAULT NULL,
  `leave_type_id` int DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`request_id`),
  KEY `employee_id` (`employee_id`),
  KEY `leave_type_id` (`leave_type_id`),
  CONSTRAINT `leave_requests_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`),
  CONSTRAINT `leave_requests_ibfk_2` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`leave_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_requests`
--

LOCK TABLES `leave_requests` WRITE;
/*!40000 ALTER TABLE `leave_requests` DISABLE KEYS */;
INSERT INTO `leave_requests` VALUES (1,1,1,'2024-02-01','2024-02-05','Approved','2024-11-14 09:50:30'),(2,2,2,'2024-03-01','2024-03-10','Pending','2024-11-14 09:50:30'),(3,3,3,'2024-04-15','2024-04-17','Denied','2024-11-14 09:50:30'),(4,4,4,'2024-05-10','2024-08-10','Approved','2024-11-14 09:50:30'),(5,5,5,'2024-06-01','2024-06-05','Approved','2024-11-14 09:50:30');
/*!40000 ALTER TABLE `leave_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_types`
--

DROP TABLE IF EXISTS `leave_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_types` (
  `leave_type_id` int NOT NULL AUTO_INCREMENT,
  `leave_name` varchar(50) DEFAULT NULL,
  `leave_code` varchar(10) DEFAULT NULL,
  `max_days` int DEFAULT NULL,
  PRIMARY KEY (`leave_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_types`
--

LOCK TABLES `leave_types` WRITE;
/*!40000 ALTER TABLE `leave_types` DISABLE KEYS */;
INSERT INTO `leave_types` VALUES (1,'Sick Leave','SL',12),(2,'Annual Leave','AL',20),(3,'Casual Leave','CL',10),(4,'Maternity Leave','ML',90),(5,'Paternity Leave','PL',10);
/*!40000 ALTER TABLE `leave_types` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-14  9:58:45
